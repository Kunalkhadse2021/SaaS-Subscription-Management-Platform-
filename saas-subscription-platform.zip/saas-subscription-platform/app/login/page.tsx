import LoginForm from "@/components/LoginForm";

export default function LoginPage() {
  return <main className="container"><div className="card form">
    <h1>Welcome back</h1><p className="muted">Sign in to your Subscribely account.</p>
    <LoginForm />
    <p className="muted" style={{fontSize:13}}>Demo admin: admin@example.com / Admin123!</p>
    <p className="muted" style={{fontSize:13}}>Demo customer: customer@example.com / Customer123!</p>
  </div></main>;
}
