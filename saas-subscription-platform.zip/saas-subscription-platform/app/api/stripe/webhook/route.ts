import { NextResponse } from "next/server";
import Stripe from "stripe";
import { headers } from "next/headers";
import { stripe } from "@/lib/stripe";
import { prisma } from "@/lib/prisma";

export async function POST(request: Request) {
  const body = await request.text();
  const signature = headers().get("stripe-signature");
  if (!signature || !process.env.STRIPE_WEBHOOK_SECRET) {
    return NextResponse.json({error:"Webhook signature configuration missing."},{status:400});
  }

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body,signature,process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Invalid signature";
    return NextResponse.json({error:`Webhook Error: ${message}`},{status:400});
  }

  try {
    if (event.type === "checkout.session.completed") {
      const session = event.data.object as Stripe.Checkout.Session;
      const userId = session.metadata?.userId;
      const planId = session.metadata?.planId;
      const stripeSubscriptionId = typeof session.subscription === "string" ? session.subscription : session.subscription?.id;
      if (userId && planId && stripeSubscriptionId) {
        const stripeSub = await stripe.subscriptions.retrieve(stripeSubscriptionId);
        await prisma.subscription.upsert({
          where:{stripeSubscriptionId},
          update:{status:"ACTIVE",stripeCustomerId:String(session.customer || ""),currentPeriodEnd:new Date(stripeSub.current_period_end*1000),planId,userId},
          create:{userId,planId,status:"ACTIVE",stripeCustomerId:String(session.customer || ""),stripeSubscriptionId,currentPeriodEnd:new Date(stripeSub.current_period_end*1000)}
        });
      }
    }

    if (event.type === "invoice.paid") {
      const invoice = event.data.object as Stripe.Invoice;
      const customerId = typeof invoice.customer === "string" ? invoice.customer : invoice.customer?.id;
      const subscriptionId = typeof invoice.subscription === "string" ? invoice.subscription : invoice.subscription?.id;
      if (customerId) {
        const sub = await prisma.subscription.findFirst({where:{stripeCustomerId:customerId},include:{user:true}});
        if (sub) {
          await prisma.invoice.upsert({
            where:{stripeInvoiceId:invoice.id},
            update:{status:"paid",hostedInvoiceUrl:invoice.hosted_invoice_url || null},
            create:{userId:sub.userId,stripeInvoiceId:invoice.id,amount:invoice.amount_paid,currency:invoice.currency,status:"paid",hostedInvoiceUrl:invoice.hosted_invoice_url || null}
          });
        }
      }
    }

    if (event.type === "customer.subscription.deleted" || event.type === "customer.subscription.updated") {
      const sub = event.data.object as Stripe.Subscription;
      const status = sub.status === "active" ? "ACTIVE" : sub.status === "past_due" ? "PAST_DUE" : sub.status === "canceled" ? "CANCELED" : "INCOMPLETE";
      await prisma.subscription.updateMany({
        where:{stripeSubscriptionId:sub.id},
        data:{status,currentPeriodEnd:new Date(sub.current_period_end*1000)}
      });
    }
    return NextResponse.json({received:true});
  } catch (error) {
    console.error("Webhook processing error:",error);
    return NextResponse.json({error:"Webhook processing failed."},{status:500});
  }
}
