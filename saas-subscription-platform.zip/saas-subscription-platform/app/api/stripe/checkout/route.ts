import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { stripe } from "@/lib/stripe";

export async function POST(request: Request) {
  try {
    const user = await getSession();
    if (!user) return NextResponse.json({error:"Please log in first."},{status:401});
    const {planId} = await request.json();
    const plan = await prisma.plan.findFirst({where:{id:planId,active:true}});
    if (!plan) return NextResponse.json({error:"Plan not found."},{status:404});
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
    const session = await stripe.checkout.sessions.create({
      mode:"subscription",
      customer_email:user.email,
      line_items:[{price_data:{
        currency:plan.currency,
        product_data:{name:`${plan.name} subscription`,description:plan.description},
        unit_amount:plan.amount,
        recurring:{interval:plan.interval as "month"|"year"}
      },quantity:1}],
      metadata:{userId:user.id,planId:plan.id},
      subscription_data:{metadata:{userId:user.id,planId:plan.id}},
      success_url:`${baseUrl}/dashboard?checkout=success`,
      cancel_url:`${baseUrl}/pricing?checkout=cancelled`
    });
    return NextResponse.json({url:session.url});
  } catch (error) {
    console.error("Stripe checkout error:",error);
    return NextResponse.json({error:"Checkout could not be created. Check your Stripe test key."},{status:500});
  }
}
