import Link from "next/link";

export default function Home() {
  return <main className="container">
    <section className="hero">
      <p><strong>SUBSCRIBELY · SUBSCRIPTION MANAGEMENT</strong></p>
      <h1>All your subscriptions, billing and usage in one place.</h1>
      <p>Explore plans, manage your subscription, track usage and view billing information from a simple dashboard.</p>
      <Link className="btn" href="/pricing">Explore plans</Link>
    </section>
    <section className="grid">
      <article className="card"><h2>Flexible plans</h2><p className="muted">Compare Starter, Pro and Business plans and choose the right capacity.</p></article>
      <article className="card"><h2>Simple billing</h2><p className="muted">Use Stripe Checkout in test mode for a secure subscription payment flow.</p></article>
      <article className="card"><h2>Usage analytics</h2><p className="muted">See recent usage totals and subscription status on your dashboard.</p></article>
    </section>
  </main>;
}
