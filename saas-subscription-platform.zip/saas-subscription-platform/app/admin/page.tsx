import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const user = await getSession();
  if (!user) redirect("/login");
  if (user.role !== "ADMIN") redirect("/dashboard");

  const [users,plans,subscriptions,invoices] = await Promise.all([
    prisma.user.count(), prisma.plan.count({where:{active:true}}),
    prisma.subscription.count(), prisma.invoice.count()
  ]);
  const latestUsers = await prisma.user.findMany({orderBy:{createdAt:"desc"},take:8,select:{id:true,name:true,email:true,role:true,createdAt:true}});
  const latestSubs = await prisma.subscription.findMany({include:{user:true,plan:true},orderBy:{createdAt:"desc"},take:8});
  return <main className="container">
    <h1>Admin panel</h1><p className="muted">Platform overview · administrator access</p>
    <section className="grid section">
      {[["Users",users],["Active plans",plans],["Subscriptions",subscriptions],["Invoices",invoices]].map(([label,value])=><article className="card" key={label}><span className="muted">{label}</span><div className="stat">{value}</div></article>)}
    </section>
    <section className="section"><h2>Latest users</h2><div className="tablewrap"><table><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th></tr></thead><tbody>
      {latestUsers.map(u=><tr key={u.id}><td>{u.name}</td><td>{u.email}</td><td>{u.role}</td><td>{u.createdAt.toLocaleDateString()}</td></tr>)}
    </tbody></table></div></section>
    <section className="section"><h2>Latest subscriptions</h2><div className="tablewrap"><table><thead><tr><th>Customer</th><th>Plan</th><th>Status</th><th>Created</th></tr></thead><tbody>
      {latestSubs.map(s=><tr key={s.id}><td>{s.user.email}</td><td>{s.plan.name}</td><td>{s.status}</td><td>{s.createdAt.toLocaleDateString()}</td></tr>)}
    </tbody></table></div></section>
  </main>;
}
