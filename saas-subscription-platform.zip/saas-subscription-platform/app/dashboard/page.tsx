import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const user = await getSession();
  if (!user) redirect("/login");

  const [subscription, usage, invoices] = await Promise.all([
    prisma.subscription.findFirst({where:{userId:user.id},include:{plan:true},orderBy:{createdAt:"desc"}}),
    prisma.usageEvent.findMany({where:{userId:user.id,createdAt:{gte:new Date(Date.now()-6*86400000)}},orderBy:{createdAt:"asc"}}),
    prisma.invoice.findMany({where:{userId:user.id},orderBy:{createdAt:"desc"},take:5})
  ]);
  const totalUsage = usage.reduce((sum,item)=>sum+item.quantity,0);
  const maxUsage = Math.max(1,...usage.map(x=>x.quantity));
  return <main className="container">
    <h1>Your dashboard</h1><p className="muted">Welcome, {user.name}. Here is your account overview.</p>
    <section className="grid section">
      <article className="card"><span className="muted">Current plan</span><div className="stat">{subscription?.plan.name || "No plan"}</div><p className="muted">{subscription?.status || "Choose a plan to get started"}</p></article>
      <article className="card"><span className="muted">Usage (last 7 days)</span><div className="stat">{totalUsage.toLocaleString()}</div><p className="muted">Usage units recorded</p></article>
      <article className="card"><span className="muted">Plan allowance</span><div className="stat">{subscription?.plan.usageLimit.toLocaleString() || "—"}</div><p className="muted">Units per month</p></article>
    </section>
    <section className="card section"><h2>Usage analytics · recent events</h2>
      {usage.length===0 ? <p className="muted">No usage events yet. Seed data is available for the demo customer.</p> :
        usage.map((item,i)=><div className="barrow" key={item.id}><span>{item.createdAt.toLocaleDateString("en-US",{month:"short",day:"numeric"})}</span><div className="bar"><span style={{width:`${Math.max(4,item.quantity/maxUsage*100)}%`}} /></div><strong>{item.quantity}</strong></div>)}
    </section>
    <section className="section"><h2>Recent invoices</h2><div className="tablewrap"><table><thead><tr><th>Date</th><th>Amount</th><th>Status</th><th>Invoice</th></tr></thead><tbody>
      {invoices.length===0 ? <tr><td colSpan={4}>No invoices recorded yet.</td></tr> : invoices.map(inv=><tr key={inv.id}><td>{inv.createdAt.toLocaleDateString()}</td><td>{(inv.amount/100).toFixed(2)} {inv.currency.toUpperCase()}</td><td>{inv.status}</td><td>{inv.hostedInvoiceUrl ? <a href={inv.hostedInvoiceUrl} target="_blank" rel="noreferrer">Open invoice</a> : "—"}</td></tr>)}
    </tbody></table></div></section>
    <p><a className="btn secondary" href="/pricing">Upgrade or change plan</a></p>
  </main>;
}
