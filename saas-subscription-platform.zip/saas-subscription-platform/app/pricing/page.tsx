import { prisma } from "@/lib/prisma";
import PlanCard from "@/components/PlanCard";

export const dynamic = "force-dynamic";

export default async function PricingPage() {
  const plans = await prisma.plan.findMany({ where:{active:true}, orderBy:{amount:"asc"} });
  return <main className="container">
    <section className="hero"><h1>Choose your plan</h1><p>All plans are billed monthly. Payments run in Stripe test mode until you add live keys.</p></section>
    <section className="grid">
      {plans.map(plan => <PlanCard key={plan.id} plan={{id:plan.id,name:plan.name,description:plan.description,amount:plan.amount,usageLimit:plan.usageLimit}} />)}
    </section>
  </main>;
}
