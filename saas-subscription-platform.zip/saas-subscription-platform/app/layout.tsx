import "./globals.css";
import Link from "next/link";
import { getSession } from "@/lib/auth";

export const metadata = {
  title: "Subscribely | SaaS Subscription Management",
  description: "Manage plans, billing, usage and subscriptions."
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const user = await getSession();
  return (
    <html lang="en">
      <body>
        <nav className="nav"><div className="navinner">
          <Link className="brand" href="/">Subscribely</Link>
          <div className="navlinks">
            <Link href="/pricing">Pricing</Link>
            {user && <Link href="/dashboard">Dashboard</Link>}
            {user?.role === "ADMIN" && <Link href="/admin">Admin</Link>}
            {user ? <form action="/api/auth/logout" method="post"><button className="btn secondary">Log out</button></form> : <Link className="btn" href="/login">Log in</Link>}
          </div>
        </div></nav>
        {children}
      </body>
    </html>
  );
}
