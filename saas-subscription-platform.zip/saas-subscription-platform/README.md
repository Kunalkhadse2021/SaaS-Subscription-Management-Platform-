# Subscribely — SaaS Subscription Management Platform

A starter full-stack subscription management application built with Next.js, Node.js route handlers, PostgreSQL, Prisma and Stripe Checkout.

## Included features

- Starter, Pro and Business monthly plans
- Login with customer/admin roles
- Stripe test-mode subscription checkout
- Stripe webhook handling for checkout, invoice paid and subscription updates
- Customer dashboard with plan, usage analytics and invoices
- Admin dashboard with users, plans, subscriptions and invoice totals
- PostgreSQL database and seed data

## Requirements

- Node.js 20 LTS (or newer compatible LTS)
- npm
- PostgreSQL 14+
- Stripe account (test mode)

## 1. Install Node.js

Download the LTS installer from https://nodejs.org/ and install it. Open a new terminal and verify:

```bash
node -v
npm -v
```

## 2. Create the PostgreSQL database

Create a database named `saas_platform` using pgAdmin or the PostgreSQL command line:

```sql
CREATE DATABASE saas_platform;
```

## 3. Install project dependencies

Open a terminal in this project folder:

```bash
npm install
```

## 4. Configure environment variables

Copy `.env.example` to `.env` (Windows PowerShell: `Copy-Item .env.example .env`; Command Prompt: `copy .env.example .env`).

Update `DATABASE_URL` with your PostgreSQL username and password. Set `AUTH_SECRET` to a long random value.

For example:

```env
DATABASE_URL="postgresql://postgres:YOUR_PASSWORD@localhost:5432/saas_platform?schema=public"
AUTH_SECRET="use-a-long-random-secret-value-here"
STRIPE_SECRET_KEY="sk_test_your_key"
STRIPE_WEBHOOK_SECRET="whsec_your_webhook_secret"
NEXT_PUBLIC_APP_URL="http://localhost:3000"
```

Get your Stripe test secret key from https://dashboard.stripe.com/test/apikeys. Never put secret keys in frontend code or commit `.env` to GitHub.

## 5. Create tables and seed demo data

```bash
npx prisma migrate dev --name init
npm run db:seed
```

If Prisma asks to generate its client, run:

```bash
npx prisma generate
```

## 6. Start the app

```bash
npm run dev
```

Open http://localhost:3000.

## Demo accounts

| Role | Email | Password |
|---|---|---|
| Admin | admin@example.com | Admin123! |
| Customer | customer@example.com | Customer123! |

Change demo passwords and the session secret before any real deployment.

## 7. Configure Stripe webhooks (for local testing)

Install the Stripe CLI from https://stripe.com/docs/stripe-cli and log in:

```bash
stripe login
stripe listen --forward-to localhost:3000/api/stripe/webhook
```

The CLI prints a webhook signing secret beginning with `whsec_`. Copy it into `.env` as `STRIPE_WEBHOOK_SECRET`, then restart the Next.js development server.

Use Stripe test card `4242 4242 4242 4242`, any future expiry date, any 3-digit CVC and any postal code. Do not use a real card.

## 8. Useful commands

```bash
npm run dev          # development server
npm run build        # production build
npm run start        # start production server after build
npx prisma studio    # view/edit database records
npm run db:seed      # add demo users and plans
```

## Project structure

```text
saas-subscription-platform/
├── app/
│   ├── api/auth/login/route.ts
│   ├── api/auth/logout/route.ts
│   ├── api/stripe/checkout/route.ts
│   ├── api/stripe/webhook/route.ts
│   ├── admin/page.tsx
│   ├── dashboard/page.tsx
│   ├── login/page.tsx
│   ├── pricing/page.tsx
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── components/
│   ├── LoginForm.tsx
│   └── PlanCard.tsx
├── lib/
│   ├── auth.ts
│   ├── prisma.ts
│   └── stripe.ts
├── prisma/
│   ├── schema.prisma
│   └── seed.ts
├── .env.example
├── package.json
└── README.md
```

## Troubleshooting

- `P1001` / database connection error: confirm PostgreSQL is running and `DATABASE_URL` credentials/database name are correct.
- `Can't reach database server`: check the PostgreSQL service and port (usually 5432).
- Stripe checkout error: check `STRIPE_SECRET_KEY` and use a test-mode `sk_test_` key.
- Webhook signature error: use the latest `whsec_` printed by `stripe listen`, save it in `.env`, and restart `npm run dev`.
- Login fails: run `npm run db:seed` and use one of the demo accounts.
- If you edit the Prisma schema, run `npx prisma migrate dev` again.

## Important production checklist

This is an educational starter/MVP, not a production billing system. Before production, add email verification, password reset, rate limiting, CSRF/origin protections, stronger audit logging, robust subscription lifecycle reconciliation, idempotent webhook event storage, tax handling, cancellation/proration flows, tests, monitoring, backups and deployment secrets management. Use HTTPS and Stripe live keys only after completing security and compliance reviews.
