 "use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

type Plan = {id:string;name:string;description:string;amount:number;usageLimit:number};
export default function PlanCard({plan}:{plan:Plan}) {
  const [busy,setBusy] = useState(false);
  const [error,setError] = useState("");
  const router = useRouter();
  async function choose() {
    setBusy(true); setError("");
    try {
      const res = await fetch("/api/stripe/checkout", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({planId:plan.id})});
      const data = await res.json();
      if (res.status === 401) { router.push("/login"); return; }
      if (!res.ok) throw new Error(data.error || "Could not start checkout");
      window.location.href = data.url;
    } catch(e) { setError(e instanceof Error ? e.message : "Checkout error"); setBusy(false); }
  }
  return <article className="card">
    <h2>{plan.name}</h2><p className="muted">{plan.description}</p>
    <div className="price">${(plan.amount/100).toFixed(2)} <small>/ month</small></div>
    <p>Up to {plan.usageLimit.toLocaleString()} usage units / month</p>
    <button className="btn" onClick={choose} disabled={busy}>{busy ? "Redirecting..." : "Choose plan"}</button>
    {error && <p className="muted">{error}</p>}
  </article>;
}
