 "use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function LoginForm() {
  const [email,setEmail] = useState("admin@example.com");
  const [password,setPassword] = useState("Admin123!");
  const [error,setError] = useState("");
  const [busy,setBusy] = useState(false);
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setError(""); setBusy(true);
    try {
      const res = await fetch("/api/auth/login", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({email,password}) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Login failed");
      router.push(data.role === "ADMIN" ? "/admin" : "/dashboard"); router.refresh();
    } catch (err) { setError(err instanceof Error ? err.message : "Login failed"); }
    finally { setBusy(false); }
  }
  return <form onSubmit={submit}>
    <label>Email</label><input className="field" type="email" required value={email} onChange={e=>setEmail(e.target.value)} />
    <label>Password</label><input className="field" type="password" required value={password} onChange={e=>setPassword(e.target.value)} />
    {error && <div className="notice error">{error}</div>}
    <button className="btn" disabled={busy}>{busy ? "Signing in..." : "Sign in"}</button>
  </form>;
}
