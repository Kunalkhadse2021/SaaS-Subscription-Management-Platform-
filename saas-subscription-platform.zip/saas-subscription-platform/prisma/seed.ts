import { PrismaClient, Role } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const adminPassword = await bcrypt.hash("Admin123!", 12);
  const customerPassword = await bcrypt.hash("Customer123!", 12);

  await prisma.user.upsert({
    where: { email: "admin@example.com" },
    update: {},
    create: {
      name: "Platform Admin",
      email: "admin@example.com",
      passwordHash: adminPassword,
      role: Role.ADMIN
    }
  });

  const customer = await prisma.user.upsert({
    where: { email: "customer@example.com" },
    update: {},
    create: {
      name: "Demo Customer",
      email: "customer@example.com",
      passwordHash: customerPassword,
      role: Role.CUSTOMER
    }
  });

  const plans = [
    { name: "Starter", description: "For individuals getting started.", amount: 900, usageLimit: 1000 },
    { name: "Pro", description: "For growing teams and businesses.", amount: 2900, usageLimit: 10000 },
    { name: "Business", description: "For teams that need more capacity.", amount: 7900, usageLimit: 50000 }
  ];

  for (const plan of plans) {
    await prisma.plan.upsert({
      where: { name: plan.name },
      update: { ...plan, active: true },
      create: { ...plan, currency: "usd", interval: "month" }
    });
  }

  const starter = await prisma.plan.findUnique({ where: { name: "Starter" } });
  if (starter) {
    const existing = await prisma.subscription.findFirst({ where: { userId: customer.id } });
    if (!existing) {
      await prisma.subscription.create({
        data: { userId: customer.id, planId: starter.id, status: "ACTIVE" }
      });
    }
    const count = await prisma.usageEvent.count({ where: { userId: customer.id } });
    if (count === 0) {
      await prisma.usageEvent.createMany({
        data: Array.from({ length: 7 }, (_, i) => ({
          userId: customer.id,
          eventType: "api_request",
          quantity: (i + 1) * 12,
          createdAt: new Date(Date.now() - (6 - i) * 86400000)
        }))
      });
    }
  }

  console.log("Seed complete. Admin: admin@example.com / Admin123!");
  console.log("Demo customer: customer@example.com / Customer123!");
}

main()
  .catch((error) => { console.error(error); process.exit(1); })
  .finally(async () => prisma.$disconnect());
